<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'vendor/autoload.php';

use MongoDB\Client as MongoDBClient;

class Welcome extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url', 'html'));
        $this->load->model('Welcome_model');
    }
	private function load_view($view_name, $data = array())
    {
        $this->load->view('include/header');
        $this->load->view('include/sidebar');
        $this->load->view($view_name, $data);
        $this->load->view('include/footer');
    }

    public function index()
    { 
        $this->load_view('dashboard');
    }

    public function add()
    {
        $this->load_view('add');
    }

   

   
    public function driver_list()
    {
        $this->load_view('driver/list');
    }
    
    public function kyc_details($_id)
    {
        $data['kyc_details'] = $this->Welcome_model->getDriverKYCDetails($_id);
        $this->load_view('driver/driver_list', $data);
    }

    public function company_details($_id)
    {
        $data['company_details'] = $this->Welcome_model->getCompanyDetails($_id);
        $this->load_view('driver/company_list', $data);
    }

	public function retailer_list()
    {
        $this->load_view('retailer/list');
    }


    public function retailer_kyc_details($_id)
    {
        $data['kyc_details'] = $this->Welcome_model->getRetailerKYCDetails($_id);
        $this->load_view('retailer/retailer_kyc_list', $data);
    }

	public function retailer_store_details($_id)
    {
        $data['store_details'] = $this->Welcome_model->getRetailerstoreDetails($_id);
        $this->load_view('retailer/retailer_store_list', $data);
    }

	public function manufacture_list()
    {
        $this->load_view('manufacture/list');
    }

	public function manufacture_kyc_details($_id)
    {
        $data['kyc_details'] = $this->Welcome_model->getManufactureKYCDetails($_id);
        $this->load_view('manufacture/manufacture_kyc_list', $data);
    }

	public function manufacture_company_details($_id)
    {
        $data['company_details'] = $this->Welcome_model->getManufacturecompanyDetails($_id);
        $this->load_view('manufacture/manufacture_company_list', $data);
    }

	public function partner_list()
    {
        $this->load_view('partner/list');
    }

	public function patner_kyc_details($_id)
    {
        $data['kyc_details'] = $this->Welcome_model->getPatnerKYCDetails($_id);
        $this->load_view('partner/partner_kyc_list', $data);
    }

	public function patner_company_details($_id)
    {

        $data['company_details'] = $this->Welcome_model->getpatnercompanyDetails($_id);
        $this->load_view('partner/partner_company_list', $data);

    }

}
