<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use MongoDB\Client as MongoDBClient;

class Welcome_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    public function getDriverKYCDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Driver;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if (isset($document['KYC'])) {
                return $document['KYC'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }

    public function getCompanyDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Driver;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if ($document && isset($document['DocumentDetails'])) {
                return $document['DocumentDetails'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }

    public function getRetailerKYCDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Retailer;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if (isset($document['KYC'])) {
                return $document['KYC'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }
    public function getRetailerstoreDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Retailer;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if ($document && isset($document['StoreDetails'])) {
                return $document['StoreDetails'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }


    public function getManufactureKYCDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Manufacture;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if (isset($document['KYC'])) {
                return $document['KYC'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }
    public function getManufacturecompanyDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Manufacture;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if ($document && isset($document['CompanyDetails'])) {
                return $document['CompanyDetails'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }



    public function getPatnerKYCDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Partner;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if (isset($document['KYC'])) {
                return $document['KYC'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }

    
    public function getpatnercompanyDetails($_id)
    {
        $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
        try {
            $mongoClient = new MongoDB\Client($mongoUri);
            $database = $mongoClient->QUIKFLO;
            $collection = $database->Patner;

            $filter = ['_id' => new MongoDB\BSON\ObjectId($_id)];
            $document = $collection->findOne($filter);

            if ($document && isset($document['CompanyDetails'])) {
                return $document['CompanyDetails'];
            } else {
                return array();
            }
        } catch (MongoDB\Driver\Exception\Exception $e) {
            echo "Error: " . $e->getMessage();
            return array();
        }
    }
}
