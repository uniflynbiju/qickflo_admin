<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manufacture Page</title>
    <style>
    .action {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
    }
    </style>
</head>

<body>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card" style="margin-top: 39px;margin-left: 25px;margin-right: 25px;">
                            <div class="card-header">
                                <h4>Manufacture Page</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Full name</th>
                                                <th>Image</th>
                                                <th>DOB</th>
                                                <th>MobileNo</th>
                                                <th>Email</th>
                                                <th>BusinessName</th>
                                                <th>Type</th>
                                                <th>KYC</th>
                                                <th>CompanyDetails</th>
                                                <th>Status</th>
                                                <!-- <th>Action</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1; // Initialize counter
                                            $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";

                                            // Connect to MongoDB
                                            try {
                                                $mongoClient = new MongoDB\Client($mongoUri);
                                                $database = $mongoClient->selectDatabase("QUIKFLO");
                                                $collection = $database->selectCollection("Manufacture");
                                                $cursor = $collection->find([]);

                                                // Output retrieved documents
                                                foreach ($cursor as $document) {
                                                    ?>
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td><?php echo $document['FullName'] ?? '-'; ?></td>
                                                <td>
                                                    <?php if (!empty($document['Image'])): ?>
                                                    <img src="<?php echo $document['Image']; ?>" alt="Image" width="100"
                                                        height="100" style="border-radius: 50%;">
                                                    <?php else: ?>
                                                    -
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $document['DOB'] ?? ''; ?></td>
                                                <td><?php echo $document['MobileNo'] ?? ''; ?></td>
                                                <td><?php echo $document['Email'] ?? ''; ?></td>
                                                <td><?php echo $document['BusinessName'] ?? ''; ?></td>
                                                <td><?php echo $document['Type'] ?? ''; ?></td>
                                                <td>
                                                    <a href="<?php echo base_url().'index.php/welcome/manufacture_kyc_details/'.$document['_id']?>"
                                                        title="KYC Details" style="color:#0d6efd;"><button type="button"
                                                            class="btn btn-primary">KYC Details</button></a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo base_url().'index.php/welcome/manufacture_company_details/'.$document['_id']?>"
                                                        title="Company Details" style="color:#0d6efd;"><button
                                                            type="button" class="btn btn-primary">Company
                                                            Details</button></a>
                                                </td>
                                                <td><?php echo $document['Status'] ?? ''; ?></td>
                                                <!-- <td class="action">
                                                            <a href="<?php //echo base_url() . 'Admin/categoryEdit/' . $document['_id'] ?>" title="Edit" style="color:#0d6efd;">
                                                                <button type="button" class="btn btn-primary">Edit</button>
                                                            </a>
                                                            <a href="<?php //echo base_url() . 'Admin/categorydelete_product/' . $document['_id'] ?>" title="Delete" style="color:#0d6efd;">
                                                                <button type="button" class="btn btn-danger">Delete</button>
                                                            </a>
                                                        </td> -->
                                            </tr>
                                            <?php
                                                    $i++;
                                                }
                                            } catch (MongoDB\Driver\Exception\Exception $e) {
                                                echo "Error: " . $e->getMessage();
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- JavaScript code -->
    <script>
    function product_status(value, id) {
        $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo base_url(); ?>Category/status",
            data: {
                id: id,
                status: value
            },
            dataType: 'json',
            success: function(data) {
                location.reload();
            }
        });
    }
    </script>
</body>

</html>