<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Page</title>
    <style>
    .action {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
    }
    </style>
</head>

<body>
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <div class="card" style="margin-top: 39px; margin-left: 25px; margin-right: 25px;">
                            <div class="card-header">
                                <h4>Partner Page</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>FullName</th>
                                                <th>Image</th>
                                                <th>MobileNumber</th>
                                                <th>Device</th>
                                                <th>PartnerCode</th>
                                                <th>DOB</th>
                                                <th>BussinessName</th>
                                                <th>Email</th>
                                                <th>KYC</th>
                                                <th>CompanyDetails</th>
                                                <th>Status</th>
                                                <!-- <th>Action</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i = 1;
                                                $mongoUri = "mongodb+srv://uniflyn:UniFlyn@quickflo.ju2k4hq.mongodb.net/?retryWrites=true&w=majority";
                                                try {
                                                    $mongoClient = new MongoDB\Client($mongoUri);
                                                    $database = $mongoClient->selectDatabase("QUIKFLO");
                                                    $collection = $database->selectCollection("Driver");
                                                    $cursor = $collection->find([]);
                                                    foreach ($cursor as $document) {
                                            ?>
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td><?php echo $document['FullName'] ?? '-'; ?></td>
                                                <td>
                                                    <?php if (!empty($document['Image'])): ?>
                                                    <img src="<?php echo $document['Image']; ?>" alt="Image" width="100"
                                                        height="100" style="border-radius: 50%;">
                                                    <?php else: ?>
                                                    -
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo isset($document['MobileNo']) ? $document['MobileNo'] : ''; ?>
                                                </td>
                                                <td><?php // echo isset($document['Device']) ? $document['Device'] : ''; ?>
                                                </td>
                                                <td><?php echo isset($document['PartnerCode']) ? $document['PartnerCode'] : ''; ?>
                                                </td>
                                                <td><?php echo isset($document['DOB']) ? $document['DOB'] : ''; ?></td>
                                                <td><?php echo isset($document['BusinessName']) ? $document['BusinessName'] : ''; ?>
                                                </td>
                                                <td><?php echo isset($document['Email']) ? $document['Email'] : ''; ?>
                                                </td>
                                                <!-- <td>
                                                    <a href="<?php echo base_url().'index.php/welcome/kyc_details/'.$document['_id']?>" title="Edit" style="color:#0d6efd;"><button type="button" class="btn btn-primary">KYC Details</button></a>
                                                </td> -->
                                                <td>
                                                    <?php if (!empty($document['KYC'])): ?>
                                                    <a href="<?php echo base_url().'index.php/welcome/kyc_details/'.$document['_id']?>"
                                                        title="Edit" style="color:#0d6efd;">
                                                        <button type="button" class="btn btn-primary">KYC
                                                            Details</button>
                                                    </a>
                                                    <?php else: ?>
                                                    No data available
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <a href="<?php echo base_url().'index.php/welcome/company_details/'.$document['_id']?>"
                                                        title="Edit" style="color:#0d6efd;"><button type="button"
                                                            class="btn btn-primary">Company Details</button></a>
                                                </td>
                                                <td><?php echo isset($document['Status']) ? $document['Status'] : ''; ?>
                                                </td>
                                                <!-- <td class="action">
                                                    <a href="<?php //echo base_url() . 'Admin/categoryEdit/' . $document['_id'] ?>" title="Edit" style="color:#0d6efd;"><button type="button" class="btn btn-primary">Edit</button></a>
                                                    <a href="<?php //echo base_url() . 'Admin/categorydelete_product/' . $document['_id'] ?>" title="Delete" style="color:#0d6efd;"><button type="button" class="btn btn-danger">Delete</button></a>
                                                </td> -->
                                            </tr>
                                            <?php
                                                        $i++;
                                                    }
                                                } catch (MongoDB\Driver\Exception\Exception $e) {
                                                    echo "Error: " . $e->getMessage();
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script>
    function product_status(value, id) {
        $.ajax({
            type: "POST",
            cache: false,
            url: "<?php echo base_url(); ?>Category/status",
            data: {
                id: id,
                status: value
            },
            dataType: 'json',
            success: function(data) {
                location.reload();
            }
        });
    }
    </script>
</body>

</html>